//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: calc_PnL.h
//
// MATLAB Coder version            : 2.8
// C/C++ source code generated on  : 22-Jul-2015 17:51:38
//
#ifndef __CALC_PNL_H__
#define __CALC_PNL_H__

// Include Files
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "../../src/calc_PnL/rt_nonfinite.h"
#include "../../src/calc_PnL/rtwtypes.h"
#include "calc_PnL_types.h"

// Function Declarations
extern void calc_PnL();

#endif

//
// File trailer for calc_PnL.h
//
// [EOF]
//
