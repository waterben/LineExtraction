/*
 * OGL01Shape3D.cpp: 3D Shapes
 */
#include <geometry/render_gl.hpp>
#ifdef WIN32
#include <windows.h>
#endif
#include <GL/glut.h>
#include <GL/gl.h>


int main(int argc, char** argv) {
    lsfm::testRenderingTR();
}
