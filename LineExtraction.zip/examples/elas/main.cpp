// modified 11/28/2013 -- added no_interpolation option via command-line
// changed 12/6/2013 to just use the ipol_gap_width parameter for this purpose

// 11/29/2013 -- changed unknown values from -10 to INFINITY when saving as .pfm

// older changes:

// modified 10/24/2013
// got rid of demo modes
// take disparity range as command line arg
// output pfms directly

// modified by DS 4/4/2013
// - added mode 'midd' to process 9 full-size pairs
// - added support for two param settings (need to recompile)
//   (1 == 'robotics', 2 == 'Middlebury', i.e. hole filling)
// - added printing of timing info
// - turned off autoscaling of disp's


static const char *usage = "\n  usage: %s im0.pgm im1.pgm disp.pfm maxdisp [no_interp=0]\n";



/*
  Copyright 2011. All rights reserved.
  Institute of Measurement and Control Systems
  Karlsruhe Institute of Technology, Germany

  This file is part of libelas.
  Authors: Andreas Geiger

  libelas is free software; you can redistribute it and/or modify it under the
  terms of the GNU General Public License as published by the Free Software
  Foundation; either version 3 of the License, or any later version.

  libelas is distributed in the hope that it will be useful, but WITHOUT ANY
  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
  PARTICULAR PURPOSE. See the GNU General Public License for more details.

  You should have received a copy of the GNU General Public License along with
  libelas; if not, write to the Free Software Foundation, Inc., 51 Franklin
  Street, Fifth Floor, Boston, MA 02110-1301, USA
*/

// Demo program showing how libelas can be used, try "./elas -h" for help

#include <ctime>
#include <iostream>
#include <algorithm>
#include <elas/elas.h>
#include <elas/image.h>


using namespace std;
using namespace lsfm;
using namespace cv;


// check whether machine is little endian
int littleendian()
{
    int intval = 1;
    uchar *uval = (uchar *)&intval;
    return uval[0] == 1;
}

// write pfm image (added by DS 10/24/2013)
// 1-band PFM image, see http://netpbm.sourceforge.net/doc/pfm.html
void WriteFilePFM(float *data, int width, int height, const char* filename, float scalefactor=1/255.0)
{
    // Open the file
    FILE *stream = fopen(filename, "wb");
    if (stream == 0) {
        fprintf(stderr, "WriteFilePFM: could not open %s\n", filename);
    exit(1);
    }

    // sign of scalefact indicates endianness, see pfms specs
    if (littleendian())
    scalefactor = -scalefactor;

    // write the header: 3 lines: Pf, dimensions, scale factor (negative val == little endian)
    fprintf(stream, "Pf\n%d %d\n%f\n", width, height, scalefactor);

    int n = width;
    // write rows -- pfm stores rows in inverse order!
    for (int y = height-1; y >= 0; y--) {
    float* ptr = data + y * width;
    // change invalid pixels (which seem to be represented as -10) to INF
    for (int x = 0; x < width; x++) {
        if (ptr[x] < 0)
        ptr[x] = INFINITY;
    }
    if ((int)fwrite(ptr, sizeof(float), n, stream) != n) {
        fprintf(stderr, "WriteFilePFM: problem writing data\n");
        exit(1);
    }
    }

    // close file
    fclose(stream);
}



// compute disparities of pgm image input pair file_1, file_2
void process (const char* file_1,const char* file_2, const char* outfile, int maxdisp, int no_interp) {


  //cout << "Processing: " << file_1 << ", " << file_2 << endl;

  // load images
  cv::Mat_<uchar> I1, I2;
  I1 = imread(file_1, IMREAD_GRAYSCALE);
  I2 = imread(file_2, IMREAD_GRAYSCALE);

  // check for correct size
  if (I1.data == NULL || I2.data == NULL || I1.cols != I2.cols || I1.rows != I2.rows) {
    cout << "ERROR: Images must be of same size, but" << endl;
    cout << "       I1: " << I1.cols <<  " x " << I1.rows <<
                 ", I2: " << I2.cols <<  " x " << I2.rows << endl;
    return;
  }

  // get image width and height
  int32_t width  = I1.cols;
  int32_t height = I1.rows;

  // allocate memory for disparity images
  const int32_t dims[3] = {width,height,I1.step[0]}; // bytes per line = width
  float* D1_data = (float*)malloc(width*height*sizeof(float));
  float* D2_data = (float*)malloc(width*height*sizeof(float));

  // process
  Elas::parameters param(Elas::MIDDLEBURY);
  if (no_interp) {
  //param = Elas::parameters(Elas::ROBOTICS);
  // don't use full 'robotics' setting, just the parameter to fill gaps
      param.ipol_gap_width = 3;
  }
  param.postprocess_only_left = false;
  param.disp_max = maxdisp;
  Elas elas(param);

  clock_t c0 = clock();

  elas.process(I1.data,I2.data,D1_data,D2_data,dims);

  // added runtime output - DS 4/4/2013
  clock_t c1 = clock();
  double secs = (double)(c1 - c0) / CLOCKS_PER_SEC;
  printf("runtime: %.2fs  (%.2fs/MP)\n", secs, secs/(width*height/1000000.0));

  // save disparity image

  WriteFilePFM(D1_data, width, height, outfile, 1.0/maxdisp);

  /*
  // process
  Elas::parameters param;
  //raj param.postprocess_only_left = false;
  Elas elas(param);
  elas.process(I1.data,I2.data,D1_data,D2_data,dims);

  // find maximum disparity for scaling output disparity images to [0..255]
  float disp_max = 0;
  for (int32_t i=0; i<width*height; i++) {
    if (D1_data[i]>disp_max) disp_max = D1_data[i];
    if (D2_data[i]>disp_max) disp_max = D2_data[i];
  }

  // copy float to uchar
  cv::Mat_<uchar> D1(height, width);
  cv::Mat_<uchar> D2(height, width);
  for (int32_t y=0; y<height; y++)
    for (int32_t x=0; x<width; x++) {
      D1(y,x) = (uint8_t)max(255.0*D1_data[y*width+x]/disp_max,0.0);
      D2(y,x) = (uint8_t)max(255.0*D2_data[y*width+x]/disp_max,0.0);
    }

  // save disparity images
  char output_1[1024];
  char output_2[1024];
  strncpy(output_1,file_1,strlen(file_1)-4);
  strncpy(output_2,file_2,strlen(file_2)-4);
  output_1[strlen(file_1)-4] = '\0';
  output_2[strlen(file_2)-4] = '\0';
  strcat(output_1,"_disp.pgm");
  strcat(output_2,"_disp.pgm");

  imwrite(output_1, D1);
  imwrite(output_2, D2);
  */

  // free memory
  free(D1_data);
  free(D2_data);
}


int main (int argc, char** argv)
{

    if (argc < 5) {
    fprintf(stderr, usage, argv[0]);
    exit(1);
    }

    const char *file1 = argv[1];
    const char *file2 = argv[2];
    const char *outfile = argv[3];
    int maxdisp = atoi(argv[4]);
    int no_interp = 0;
    if (argc > 5)
    no_interp = atoi(argv[5]);

    process(file1, file2, outfile, maxdisp, no_interp);

    return 0;
}

/*
int main (int argc, char** argv) {

  // run demo
  if (argc==2 && !strcmp(argv[1],"demo")) {
    process("img/cones_left.pgm",   "img/cones_right.pgm");
    process("img/aloe_left.pgm",    "img/aloe_right.pgm");
    process("img/raindeer_left.pgm","img/raindeer_right.pgm");
    process("img/urban1_left.pgm",  "img/urban1_right.pgm");
    process("img/urban2_left.pgm",  "img/urban2_right.pgm");
    process("img/urban3_left.pgm",  "img/urban3_right.pgm");
    process("img/urban4_left.pgm",  "img/urban4_right.pgm");
    cout << "... done!" << endl;

  // compute disparity from input pair
  } else if (argc==3) {
    process(argv[1],argv[2]);
    cout << "... done!" << endl;

  // display help
  } else {
    cout << endl;
    cout << "ELAS demo program usage: " << endl;
    cout << "./elas demo ................ process all test images (image dir)" << endl;
    cout << "./elas left.pgm right.pgm .. process a single stereo pair" << endl;
    cout << "./elas -h .................. shows this help" << endl;
    cout << endl;
    cout << "Note: All images must be pgm greylevel images. All output" << endl;
    cout << "      disparities will be scaled such that disp_max = 255." << endl;
    cout << endl;
  }

  return 0;
}
*/
